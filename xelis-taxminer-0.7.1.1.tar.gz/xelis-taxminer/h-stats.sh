#!/usr/bin/env bash
source /hive/miners/custom/xelis-taxminer/h-manifest.conf

start_time=$(date +%s)

get_cpu_temps () {
  local t_core=`cpu-temp`
  local i=0
  local l_num_cores=$1
  local l_temp=
  for (( i=0; i < ${l_num_cores}; i++ )); do
    l_temp+="$t_core "
  done
  echo ${l_temp[@]} | tr " " "\n" | jq -cs '.'
}

get_cpu_fans () {
  local t_fan=0
  local i=0
  local l_num_cores=$1
  local l_fan=
  for (( i=0; i < ${l_num_cores}; i++ )); do
    l_fan+="$t_fan "
  done
  echo ${l_fan[@]} | tr " " "\n" | jq -cs '.'
}

#get_cpu_bus_numbers () {
#  local i=0
#  local l_num_cores=$1
#  local l_numbers=
#  for (( i=0; i < ${l_num_cores}; i++ )); do
#    l_numbers+="null "
#  done
#  echo ${l_numbers[@]} | tr " " "\n" | jq -cs '.'
#}

get_miner_uptime(){
    local start_time=$(cat "/tmp/miner_start_time")
    local current_time=$(date +%s)
    let uptime=current_time-start_time
    echo $uptime
}

get_log_time_diff(){
  local a=0
  let a=`date +%s`-`stat --format='%Y' $log_name`
  echo $a
}

get_average_its() {
   echo $(awk -F': ' '/Total hashrate:/ {split($2, a, " "); last_value = a[1]/1000} END {print last_value}' "${CUSTOM_LOG_BASENAME}.log")

}
get_accepted_solutions() {

   if [ -f "/hive/miners/custom/xelis-taxminer/solutions_log.txt" ]; then
      cat "/hive/miners/custom/xelis-taxminer/solutions_log.txt"
   fi
}


# GPUs

gpu_stats_nvidia=$(jq '[.brand, .temp, .fan, .power, .busids, .mtemp, .jtemp] | transpose | map(select(.[0] == "nvidia")) | transpose' <<< $gpu_stats)
gpu_temp=$(jq -c '[.[1][]]' <<< "$gpu_stats_nvidia")
gpu_fan=$(jq -c '[.[2][]]' <<< "$gpu_stats_nvidia")
gpu_bus=$(jq -c '[.[4][]]' <<< "$gpu_stats_nvidia")
gpu_count=$(jq '.busids | select(. != null) | length' <<< $gpu_stats)



uptime=$(get_miner_uptime)
[[ $uptime -lt 60 ]] && head -n 50 $log_name > $log_head_name
echo "miner uptime is: $uptime"

cpu_temp=`cpu-temp`
[[ $cpu_temp = "" ]] && cpu_temp=null

cpu_is_working=$( [[ -f "$conf_cpu" ]] && echo "yes" || echo "no" )

stats=""
algo="xelis"
uptime=$(get_miner_uptime)
khs=$(get_average_its)
hs_units="hs"


lines_to_process=$((gpu_count * 2 + 2))
declare -A hs  # Declare an associative array to store hashrate values

while IFS= read -r line; do
	#echo "$line"
     if echo "$line" | grep --color=always -Eq 'GPU.#.'; then  # Escaping brackets and using ERE
        # Extract the GPU ID
        #gpu=$(echo "$line" | grep "GPU" | awk -F'[] [#]+' '{print $3}') # Using awk to split by 'GPU #'
	gpu=$(echo "$line" | awk -F'[# ]' '{print $3}')  # Split on both # and space, extract third field
        echo "found $gpu"

        # Extract the hashrate (H/s value)
        #hashrate=$(echo "$line" | awk -F'=' '{print $2}' | awk '{print $1}') # Split by '=' and take the first part
	hashrate=$(echo "$line" | awk -F'=' '{print $2}' | awk '{print $1}')


        # Debug line to show which GPU and hashrate
        echo "GPU $gpu has a hashrate of $hashrate H/s $line"

        # Store the hashrate value in the associative array
        hs[$gpu]=$hashrate
    else
       echo "no line"
    fi
done < <(tail -n "$lines_to_process" "${CUSTOM_LOG_BASENAME}.log")

for gpu in "${!hs[@]}"; do
    echo "GPU $gpu hashrate: ${hs[$gpu]} H/s"
done

#for gpu in "${!hs[@]}"; do
#    echo "GPU $gpu hashrate: ${hs[$gpu]} H/s"
#done
#
# for each gpu
#
for (( i=0; i < ${gpu_count}; i++ )); do
   busid=$(jq .[$i] <<< "$gpu_bus")
   bus_numbers[$i]=`echo $busid | cut -d ":" -f1 | cut -c2- | awk -F: '{ printf "%d\n",("0x"$1) }'`
done

ver=$(cat  "/tmp/.xelis-taxminer-version" )



total_khs=$khs
#ac=$(get_accepted_solutions)
ac=0
rj=0
stats=$(jq -nc \
        --argjson total_khs "$total_khs" \
        --argjson khs "$total_khs" \
        --arg hs_units "$hs_units" \
        --argjson hs "$(echo "${hs[@]}" | jq -Rcs 'split(" ")')" \
        --argjson temp "${gpu_temp}"                               \
        --argjson fan "${gpu_fan}"                                 \
        --arg uptime "$uptime" \
        --arg ver "$ver" \
        --arg ac "$ac" --arg rj "$rj" \
        --arg algo "$algo" \
        --argjson bus_numbers "`echo ${bus_numbers[@]} | tr " " "\n" | jq -cs '.'`" \
        '{$total_khs, $khs, $hs_units, $hs, $temp, $fan, $uptime, $ver, ar: [$ac, $rj], $algo, $bus_numbers}')
# debug output

 echo khs:   $hs
 echo stats: $stats
 echo ----------
